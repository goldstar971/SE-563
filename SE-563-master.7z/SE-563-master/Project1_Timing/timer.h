#include "stm32l476xx.h"

void TIM_Init(TIM_TypeDef *timx);


