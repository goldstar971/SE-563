#ifndef __BANK__H
#define __BANK__H 

#include "people.h"

#define NUMBER_OF_TELLERS ( 3 )

typedef struct {
	teller *workers[NUMBER_OF_TELLERS];	// Array of Tellers Who Handle Customers
	customer *queue[MAX_QUEUE_SIZE];	// Array of Customers Who Wait for Available Teller
	int begining_of_line;				// Index of Next Customer in Queue
	int end_of_line;					// Index of Next Empty Space in Queue
} Bank;

customer * get_next_customer(Bank *building);
void add_customer(Bank *building, customer *person);
void add_teller(Bank *building, teller *person);
void daily_operation();

#endif
