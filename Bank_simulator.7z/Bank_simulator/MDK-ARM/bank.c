#include "bank.h"
#include <stdio.h>

extern Bank bank;

//	-------
//	Methods
//	-------

/*
 * Retrieves the next Customer in the queue from a Bank.
 *	@*building Bank passed by reference, holds the queue
 * Returns a pointer to the Customer.
 */
customer * get_next_customer(Bank *building) {
	customer *next_customer = building->queue[building->begining_of_line];
	building->queue[building->begining_of_line] = NULL;
	
	// No Customer Ready - Don't Alter Queue Index
	if(next_customer == NULL) {
		return NULL;
	}
	
	// Customer Was Ready - Update Queue Index
	if(building->begining_of_line >= (MAX_QUEUE_SIZE - 1)) {
		building->begining_of_line = 0;
	}
	else {
		building->begining_of_line++;
	}
	
	return next_customer;
}

/*
 * Adds a Customer to the queue in a Bank.
 *	@*building Bank that holds the queue
 *	@*person Customer to be added to the queue
 */
void add_customer(Bank *building, customer *person) {
	customer *check_spot = building->queue[building->end_of_line];
	
	// Spot Taken in Queue - Can't Add
	if(check_spot != NULL) {
		return;
	}
	else {	// Add Customer to Queue
		building->queue[building->end_of_line] = person;
	}
	
	// Customer Added - Update Queue Index
	if(building->end_of_line >= (MAX_QUEUE_SIZE - 1)) {
		building->end_of_line = 0;
	}
	else {
		building->end_of_line++;
	}
}

/*
 * Adds a Teller to the Bank.
 *	@*building Bank that holds the tellers
 *	@*person Teller to be added to the Bank
 */
void add_teller(Bank *building, teller *person) {
	for(int i = 0; i < NUMBER_OF_TELLERS; i++) {
		if(building->workers[i] == NULL) {
			building->workers[i] = person;
			break;
		}
	}
	// Could Not Add Teller
}

/*
 * Simulates the operations of a Bank. Generates and adds Customers to the Bank.
 * Cycles through Tellers and assigns Customers from the queue to Tellers who are
 * waiting for work.
 */
void daily_operation() {
	
}
