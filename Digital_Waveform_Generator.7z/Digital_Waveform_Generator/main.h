#ifndef __main_H
#define __main_H

#define MAX_BUFFER_CMD ( 6 )
#define TWENTY_MS ( 1999 )
#define ONE_HUNDRED_MS ( 9999 )

#endif
